# assistant_learnable.py
import spacy
import random
import datetime
import requests
import json
import os

# Load spaCy model for NLP (replace with a more complex model if needed)
nlp = spacy.load("en_core_web_sm")

# Intent classification examples (train the assistant with new data over time)
TRAINING_DATA = [
    ("Hello", {"intent": "greeting"}),
    ("Hi there", {"intent": "greeting"}),
    ("What time is it?", {"intent": "time"}),
    ("Tell me the time", {"intent": "time"}),
    ("What's the date today?", {"intent": "date"}),
    ("Check weather in New York", {"intent": "weather"}),
    ("What's the weather in Paris?", {"intent": "weather"})
]

intent_responses = {
    "greeting": ["Hello! How can I assist you today?", "Hi there! What can I do for you?"],
    "time": ["The current time is {}.", "It's {} right now."],
    "date": ["Today is {}.", "The date today is {}."],
    "weather": ["Let me check the weather for you. The temperature in {} is {}°C."],
    "unknown": ["I'm not sure how to respond to that.", "Can you please clarify your request?"]
}

def get_time():
    return datetime.datetime.now().strftime("%H:%M")

def get_date():
    return datetime.datetime.now().strftime("%A, %B %d, %Y")

def get_weather(city):
    api_key = "your_openweather_api_key"
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data['main']['temp']
    else:
        return None

def save_training_data(new_training_data):
    """Append new training data to a file."""
    with open('training_data.json', 'a') as f:
        json.dump(new_training_data, f)
        f.write("\n")

def load_training_data():
    """Load existing training data from a file."""
    if os.path.exists('training_data.json'):
        with open('training_data.json', 'r') as f:
            return [json.loads(line) for line in f]
    return []

def train_model(training_data):
    """Train the spaCy model on new training data."""
    from spacy.tokens import DocBin

    # Create a blank NLP model
    model = spacy.blank("en")
    doc_bin = DocBin()

    # Prepare training examples
    for text, annotation in training_data:
        doc = model.make_doc(text)
        doc.cats = {label: 1.0 if label == annotation["intent"] else 0.0 for label in intent_responses}
        doc_bin.add(doc)

    # Train the model (This is a simple setup for illustration. A real model would require more training time)
    model.initialize()
    model.to_disk("trained_model")  # Save the model

def get_intent(user_input):
    """Determines the user's intent using the NLP model."""
    doc = nlp(user_input)
    max_intent = max(doc.cats, key=doc.cats.get)
    return max_intent if doc.cats[max_intent] > 0.5 else "unknown"

def handle_intent(intent, user_input=None):
    if intent == "greeting":
        return random.choice(intent_responses["greeting"])
    elif intent == "time":
        return random.choice(intent_responses["time"]).format(get_time())
    elif intent == "date":
        return random.choice(intent_responses["date"]).format(get_date())
    elif intent == "weather":
        city = user_input.split("in")[-1].strip() if "in" in user_input else None
        if city:
            temp = get_weather(city)
            if temp:
                return random.choice(intent_responses["weather"]).format(city, temp)
            else:
                return f"Sorry, I couldn't retrieve the weather for {city}."
        else:
            return "Please specify a city for the weather."
    else:
        return random.choice(intent_responses["unknown"])

def main():
    print("Welcome to the AI Assistant! Type 'exit' to quit. You can also help me learn by providing feedback.")
    
    # Load existing training data and retrain the model (if data exists)
    training_data = load_training_data()
    if training_data:
        train_model(training_data)

    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == "exit":
            print("Goodbye!")
            break

        intent = get_intent(user_input)
        response = handle_intent(intent, user_input)
        print(f"AI: {response}")

        # Ask for feedback if intent detection is incorrect
        if intent == "unknown":
            correct_intent = input("Can you help me understand? What should my response have been (greeting, time, date, weather)? ")
            if correct_intent in intent_responses:
                # Save this training example for future training
                new_training_data = (user_input, {"intent": correct_intent})
                save_training_data(new_training_data)
                print("Thanks! I'll remember that.")

if __name__ == "__main__":
    main()
