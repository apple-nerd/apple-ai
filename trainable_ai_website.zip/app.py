from flask import Flask, request, jsonify
import random
import spacy
import json
import os

app = Flask(__name__)

nlp = spacy.load("en_core_web_sm")

intent_responses = {
    "greeting": ["Hello! How can I assist you today?", "Hi there! What can I do for you?"],
    "time": ["The current time is {}.", "It's {} right now."],
    "date": ["Today is {}.", "The date today is {}."],
    "weather": ["Please specify a city for the weather."],
    "unknown": ["I'm not sure how to respond to that.", "Can you please clarify your request?"]
}

def get_time():
    from datetime import datetime
    return datetime.now().strftime("%H:%M")

def get_date():
    from datetime import datetime
    return datetime.now().strftime("%A, %B %d, %Y")

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    user_input = data['message']
    
    intent = classify_intent(user_input)
    response = generate_response(intent, user_input)
    
    return jsonify({'reply': response})

def classify_intent(user_input):
    doc = nlp(user_input)
    if "hello" in user_input.lower() or "hi" in user_input.lower():
        return "greeting"
    elif "time" in user_input.lower():
        return "time"
    elif "date" in user_input.lower():
        return "date"
    elif "weather" in user_input.lower():
        return "weather"
    else:
        return "unknown"

def generate_response(intent, user_input=None):
    if intent == "greeting":
        return random.choice(intent_responses["greeting"])
    elif intent == "time":
        return random.choice(intent_responses["time"]).format(get_time())
    elif intent == "date":
        return random.choice(intent_responses["date"]).format(get_date())
    elif intent == "weather":
        return intent_responses["weather"][0]
    else:
        return random.choice(intent_responses["unknown"])

if __name__ == '__main__':
    app.run(debug=True)
